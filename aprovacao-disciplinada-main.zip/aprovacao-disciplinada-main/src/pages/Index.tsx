import { lazy, Suspense } from "react";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { WhatsAppButton } from "@/components/WhatsAppButton";

// Lazy load components below the fold for faster initial load
const DemoSection = lazy(() => import("@/components/DemoSection").then(m => ({ default: m.DemoSection })));
const SatisfiedStudentsSection = lazy(() => import("@/components/SatisfiedStudentsSection").then(m => ({ default: m.SatisfiedStudentsSection })));
const WhyItWorksSection = lazy(() => import("@/components/WhyItWorksSection").then(m => ({ default: m.WhyItWorksSection })));
const HowItWorksSection = lazy(() => import("@/components/HowItWorksSection").then(m => ({ default: m.HowItWorksSection })));
const TestimonialsSection = lazy(() => import("@/components/TestimonialsSection").then(m => ({ default: m.TestimonialsSection })));
const ForWhoSection = lazy(() => import("@/components/ForWhoSection").then(m => ({ default: m.ForWhoSection })));
const BonusSection = lazy(() => import("@/components/BonusSection").then(m => ({ default: m.BonusSection })));
const PricingSection = lazy(() => import("@/components/PricingSection").then(m => ({ default: m.PricingSection })));
const VideoTestimonialsSection = lazy(() => import("@/components/VideoTestimonialsSection").then(m => ({ default: m.VideoTestimonialsSection })));
const GuaranteeSection = lazy(() => import("@/components/GuaranteeSection").then(m => ({ default: m.GuaranteeSection })));
const FAQSection = lazy(() => import("@/components/FAQSection").then(m => ({ default: m.FAQSection })));
const Footer = lazy(() => import("@/components/Footer").then(m => ({ default: m.Footer })));

// Minimal loading placeholder
const SectionLoader = () => (
  <div className="min-h-[200px] flex items-center justify-center">
    <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
  </div>
);

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <HeroSection />
        <Suspense fallback={<SectionLoader />}>
          <DemoSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <SatisfiedStudentsSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <WhyItWorksSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <HowItWorksSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <TestimonialsSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <ForWhoSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <BonusSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <PricingSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <VideoTestimonialsSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <GuaranteeSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <FAQSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <Footer />
        </Suspense>
      </main>
      <WhatsAppButton />
    </div>
  );
};

export default Index;
