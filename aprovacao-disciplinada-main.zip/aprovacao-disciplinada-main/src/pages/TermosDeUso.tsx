import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const TermosDeUso = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="container py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao início
            </Button>
          </Link>

          <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-8">
            Termos de <span className="text-gradient">Uso</span>
          </h1>

          <div className="prose prose-invert max-w-none space-y-6 text-muted-foreground">
            <p className="text-lg">
              Última atualização: Dezembro de 2024
            </p>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">1. Aceitação dos Termos</h2>
              <p>
                Ao acessar e utilizar a plataforma Concurso Simples, você concorda em cumprir e estar 
                vinculado aos presentes Termos de Uso. Se você não concordar com qualquer parte destes 
                termos, não poderá acessar ou usar nossos serviços.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">2. Descrição do Serviço</h2>
              <p>
                O Concurso Simples é uma plataforma educacional especializada em preparação para 
                concursos militares, oferecendo:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Videoaulas organizadas por disciplina</li>
                <li>Apostilas e materiais de estudo</li>
                <li>Simulados e questões de provas anteriores</li>
                <li>Ferramentas de inteligência artificial para análise de desempenho</li>
                <li>Cronogramas de estudo personalizados</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">3. Cadastro e Conta</h2>
              <p>
                Para utilizar nossos serviços, você deve criar uma conta fornecendo informações 
                precisas e completas. Você é responsável por manter a confidencialidade de sua 
                senha e por todas as atividades realizadas em sua conta.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">4. Planos e Pagamentos</h2>
              <p>
                Oferecemos diferentes planos de assinatura (Recruta, Combatente e Guerreiro). 
                Os pagamentos são processados de forma segura através de nossos parceiros de 
                pagamento. Os valores e benefícios de cada plano estão descritos em nossa 
                página de preços.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">5. Política de Cancelamento</h2>
              <p>
                Você pode cancelar sua assinatura a qualquer momento. O acesso aos serviços 
                continuará até o final do período já pago. Oferecemos garantia de 7 dias 
                para novos assinantes.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">6. Propriedade Intelectual</h2>
              <p>
                Todo o conteúdo disponibilizado na plataforma, incluindo textos, vídeos, 
                imagens e materiais didáticos, é protegido por direitos autorais. É proibida 
                a reprodução, distribuição ou compartilhamento não autorizado do conteúdo.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">7. Uso Aceitável</h2>
              <p>
                Ao usar nossa plataforma, você concorda em:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Não compartilhar sua conta com terceiros</li>
                <li>Não distribuir ou revender o conteúdo</li>
                <li>Não utilizar métodos automatizados para acessar o serviço</li>
                <li>Respeitar os demais usuários e nossa equipe</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">8. Limitação de Responsabilidade</h2>
              <p>
                O Concurso Simples não garante aprovação em concursos. Nosso serviço é uma 
                ferramenta de apoio aos estudos, e o resultado final depende do esforço 
                e dedicação individual de cada usuário.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">9. Alterações nos Termos</h2>
              <p>
                Reservamo-nos o direito de modificar estes termos a qualquer momento. 
                As alterações entrarão em vigor após sua publicação na plataforma. 
                O uso continuado dos serviços após as alterações constitui aceitação 
                dos novos termos.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">10. Contato</h2>
              <p>
                Para dúvidas sobre estes Termos de Uso, entre em contato conosco através do 
                e-mail: suporte@concursosimples.com.br
              </p>
            </section>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default TermosDeUso;
