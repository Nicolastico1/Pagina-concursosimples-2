import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const PoliticaPrivacidade = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="container py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Link to="/">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao início
            </Button>
          </Link>

          <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-8">
            Política de <span className="text-gradient">Privacidade</span>
          </h1>

          <div className="prose prose-invert max-w-none space-y-6 text-muted-foreground">
            <p className="text-lg">
              Última atualização: Dezembro de 2024
            </p>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">1. Introdução</h2>
              <p>
                O Concurso Simples está comprometido com a proteção da privacidade de nossos 
                usuários. Esta Política de Privacidade descreve como coletamos, usamos, 
                armazenamos e protegemos suas informações pessoais.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">2. Informações Coletadas</h2>
              <p>
                Coletamos as seguintes categorias de informações:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li><strong>Dados de cadastro:</strong> nome, e-mail, telefone</li>
                <li><strong>Dados de pagamento:</strong> informações de cartão (processadas por terceiros seguros)</li>
                <li><strong>Dados de uso:</strong> progresso nos estudos, desempenho em simulados, tempo de acesso</li>
                <li><strong>Dados técnicos:</strong> endereço IP, tipo de navegador, dispositivo utilizado</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">3. Uso das Informações</h2>
              <p>
                Utilizamos suas informações para:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Fornecer e melhorar nossos serviços educacionais</li>
                <li>Personalizar sua experiência de aprendizado</li>
                <li>Processar pagamentos e gerenciar sua assinatura</li>
                <li>Enviar comunicações sobre seu plano e novidades</li>
                <li>Analisar e melhorar a plataforma</li>
                <li>Prevenir fraudes e garantir a segurança</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">4. Compartilhamento de Dados</h2>
              <p>
                Não vendemos suas informações pessoais. Podemos compartilhar dados com:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Processadores de pagamento para transações financeiras</li>
                <li>Provedores de serviços que nos auxiliam na operação</li>
                <li>Autoridades legais quando exigido por lei</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">5. Segurança dos Dados</h2>
              <p>
                Implementamos medidas de segurança técnicas e organizacionais para proteger 
                suas informações, incluindo:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Criptografia de dados em trânsito e em repouso</li>
                <li>Controles de acesso rigorosos</li>
                <li>Monitoramento contínuo de segurança</li>
                <li>Backups regulares</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">6. Cookies e Tecnologias Similares</h2>
              <p>
                Utilizamos cookies para melhorar sua experiência na plataforma. Os cookies nos 
                ajudam a lembrar suas preferências, analisar o uso do site e personalizar conteúdo.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">7. Seus Direitos (LGPD)</h2>
              <p>
                De acordo com a Lei Geral de Proteção de Dados (LGPD), você tem direito a:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Confirmar a existência de tratamento de seus dados</li>
                <li>Acessar seus dados pessoais</li>
                <li>Corrigir dados incompletos ou desatualizados</li>
                <li>Solicitar anonimização ou eliminação de dados</li>
                <li>Revogar consentimento</li>
                <li>Solicitar portabilidade dos dados</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">8. Retenção de Dados</h2>
              <p>
                Mantemos suas informações enquanto sua conta estiver ativa ou conforme necessário 
                para fornecer nossos serviços. Após o encerramento da conta, podemos reter alguns 
                dados por períodos determinados para cumprir obrigações legais.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">9. Menores de Idade</h2>
              <p>
                Nossos serviços são destinados a pessoas maiores de 18 anos. Se você é menor de 
                idade, deve utilizar a plataforma com supervisão e consentimento dos pais ou 
                responsáveis legais.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">10. Alterações na Política</h2>
              <p>
                Podemos atualizar esta política periodicamente. Notificaremos sobre mudanças 
                significativas através da plataforma ou por e-mail.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">11. Contato</h2>
              <p>
                Para exercer seus direitos ou esclarecer dúvidas sobre esta política, 
                entre em contato através do e-mail: suporte@concursosimples.com.br
              </p>
            </section>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default PoliticaPrivacidade;
