import { motion } from "framer-motion";
import { useEffect } from "react";

export const VideoTestimonialsSection = () => {
  // Load Wistia scripts
  useEffect(() => {
    const playerScript = document.createElement('script');
    playerScript.src = 'https://fast.wistia.com/player.js';
    playerScript.async = true;
    document.head.appendChild(playerScript);

    const embedScript = document.createElement('script');
    embedScript.src = 'https://fast.wistia.com/embed/bf3ti75obd.js';
    embedScript.async = true;
    embedScript.type = 'module';
    document.head.appendChild(embedScript);

    return () => {
      document.head.removeChild(playerScript);
      document.head.removeChild(embedScript);
    };
  }, []);

  return (
    <section className="py-20 bg-muted/30 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,hsl(199,100%,40%,0.05),transparent_70%)]" />
      
      <div className="container relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold">
            Quem Está Falando Sobre a <br className="sm:hidden" /><span className="text-gradient">Concurso Simples</span>
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-2xl mx-auto"
        >
          <div className="relative rounded-2xl overflow-hidden border border-border shadow-xl bg-card p-3">
            <div className="rounded-xl overflow-hidden">
              <style>
                {`
                  wistia-player[media-id='bf3ti75obd']:not(:defined) {
                    background: center / contain no-repeat url('https://fast.wistia.com/embed/medias/bf3ti75obd/swatch');
                    display: block;
                    filter: blur(5px);
                    padding-top: 56.46%;
                  }
                `}
              </style>
              {/* @ts-ignore */}
              <wistia-player media-id="bf3ti75obd" aspect="1.7712177121771218"></wistia-player>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
