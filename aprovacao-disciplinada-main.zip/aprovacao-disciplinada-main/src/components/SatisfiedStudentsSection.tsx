import { motion } from "framer-motion";
import { GripHorizontal, Star } from "lucide-react";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";

// Import satisfied student images
import fernanda from "@/assets/satisfied/fernanda.webp";
import felipe from "@/assets/satisfied/felipe.webp";
import depoi3 from "@/assets/satisfied/depoi_3.webp";
import julia from "@/assets/satisfied/julia.webp";
import lucas from "@/assets/satisfied/lucas.webp";
import depoi2 from "@/assets/satisfied/depoi_2.webp";
import lorena from "@/assets/satisfied/lorena.webp";
import amanda from "@/assets/satisfied/amanda.webp";
import depoi1 from "@/assets/satisfied/depoi_1.webp";

const testimonialImages = [
  { src: fernanda, alt: "Depoimento da Fernanda" },
  { src: felipe, alt: "Depoimento do Felipe" },
  { src: depoi3, alt: "Depoimento de aluno" },
  { src: julia, alt: "Depoimento da Julia" },
  { src: lucas, alt: "Depoimento do Lucas" },
  { src: depoi2, alt: "Depoimento de aluno" },
  { src: lorena, alt: "Depoimento da Lorena" },
  { src: amanda, alt: "Depoimento da Amanda" },
  { src: depoi1, alt: "Depoimento de aluno" },
];

export const SatisfiedStudentsSection = () => {
  const [emblaRef] = useEmblaCarousel(
    { loop: true, dragFree: true, align: "start" },
    [Autoplay({ delay: 3000, stopOnInteraction: true, stopOnMouseEnter: true })]
  );

  return (
    <section className="py-16 bg-background relative overflow-hidden">
      <div className="container mb-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/30 text-secondary text-sm font-medium mb-6">
            <Star className="w-4 h-4 fill-secondary" />
            Depoimentos Reais
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Alunos <span className="text-gradient">Satisfeitos!</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-2">
            Veja o que nossos alunos estão dizendo sobre a transformação nos estudos
          </p>
        </motion.div>
      </div>

      {/* Drag hint */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="flex items-center justify-center gap-2 text-muted-foreground text-sm mb-6"
      >
        <GripHorizontal className="w-4 h-4" />
        <span>Arraste para ver mais</span>
      </motion.div>

      {/* Carousel */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="container"
      >
        <div className="relative">
          {/* Gradient overlays - same as DemoSection */}
          <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />

          <div className="overflow-hidden cursor-grab active:cursor-grabbing" ref={emblaRef}>
            <div className="flex gap-4">
              {[...testimonialImages, ...testimonialImages, ...testimonialImages].map((image, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 w-56 lg:w-64"
                >
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-auto rounded-xl shadow-lg hover:scale-105 transition-transform duration-300"
                    draggable="false"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
};
