import { motion } from "framer-motion";
import { Check, X } from "lucide-react";

export const ForWhoSection = () => {
  const forWho = [
    "Quer passar em concursos militares (ESA, EsPCEx, EEAR, Marinha...)",
    "Está disposto a estudar com método e disciplina",
    "Quer economizar tempo estudando o que realmente importa",
    "Precisa de organização e acompanhamento do progresso",
    "Busca uma plataforma completa, tudo em um só lugar",
  ];

  const notForWho = [
    "Busca milagre ou aprovação sem esforço",
    "Não está disposto a dedicar tempo aos estudos",
    "Quer apenas materiais soltos, sem método",
    "Não leva a sério sua preparação",
  ];

  return (
    <section className="py-20 bg-background relative">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Para quem é a <span className="text-gradient">Concurso Simples</span>?
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* For Who */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="p-8 rounded-2xl bg-card border border-secondary/30 relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-secondary/5 to-transparent" />
            <div className="relative">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/30 text-secondary text-sm font-medium mb-6">
                <Check className="w-4 h-4" />
                É para você se...
              </div>
              <ul className="space-y-4">
                {forWho.map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-secondary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-4 h-4 text-secondary" />
                    </div>
                    <span className="text-foreground/90">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Not For Who */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="p-8 rounded-2xl bg-card border border-destructive/30 relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-destructive/5 to-transparent" />
            <div className="relative">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-destructive/10 border border-destructive/30 text-destructive text-sm font-medium mb-6">
                <X className="w-4 h-4" />
                Não é para você se...
              </div>
              <ul className="space-y-4">
                {notForWho.map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-destructive/20 flex items-center justify-center shrink-0 mt-0.5">
                      <X className="w-4 h-4 text-destructive" />
                    </div>
                    <span className="text-foreground/90">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
