import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Star, Zap, Crown } from "lucide-react";
import { CheckoutPopup } from "./CheckoutPopup";

const ToggleIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="shrink-0">
    <rect x="1" y="5" width="22" height="14" rx="7" fill="hsl(199, 100%, 40%)" stroke="hsl(199, 100%, 40%)" strokeWidth="2"/>
    <circle cx="16" cy="12" r="5" fill="white"/>
  </svg>
);

export const PricingSection = () => {
  const [selectedPlan, setSelectedPlan] = useState<{ name: string; link: string } | null>(null);
  // Reordenado: Recruta, Guerreiro (meio/destaque), Combatente
  const plans = [
    {
      name: "Recruta",
      icon: Star,
      description: "Para quem está começando sua jornada",
      price: "67",
      billing: "Faturado mensalmente",
      sections: [
        {
          title: "APOSTILAS",
          items: ["PORTUGUÊS", "MATEMÁTICA", "QUÍMICA", "FÍSICA", "INGLÊS..."],
        },
        {
          title: "PLATAFORMA",
          items: ["+ 50 Video Aulas"],
        },
      ],
      cta: "Começar agora",
      popular: false,
      link: "https://pay.kiwify.com.br/DkxXr3x",
    },
    {
      name: "Combatente",
      icon: Zap,
      description: "Para quem quer acelerar a aprovação",
      price: "97",
      billing: "Faturado mensalmente",
      sections: [
        {
          title: "APOSTILAS",
          items: ["PORTUGUÊS", "MATEMÁTICA", "QUÍMICA", "FÍSICA", "INGLÊS..."],
        },
        {
          title: "PLATAFORMA",
          items: [
            "+ 50 Video Aulas",
            "Filtro de Questões",
            "Gráfico de Desempenho",
            "Simulados",
            "Estudo por Disciplinas",
            "Filtro de Dificuldade",
            "Inteligências Artificiais",
            "Análise de Redação",
            "Cronograma de Estudo",
            "Tira Dúvidas e Resolução",
            "IA de Aceleração Cognitiva",
          ],
        },
      ],
      cta: "Começar agora",
      popular: false,
      link: "https://pay.kiwify.com.br/xvGeavF",
    },
    {
      name: "Guerreiro",
      icon: Crown,
      description: "Melhor custo-benefício anual",
      price: "67",
      billing: "Faturado anualmente",
      originalPrice: "97",
      sections: [
        {
          title: "APOSTILAS",
          items: ["PORTUGUÊS", "MATEMÁTICA", "QUÍMICA", "FÍSICA", "INGLÊS..."],
        },
        {
          title: "PLATAFORMA",
          items: [
            "+ 50 Video Aulas",
            "Filtro de Questões",
            "Gráfico de Desempenho",
            "Simulados",
            "Estudo por Disciplinas",
            "Filtro de Dificuldade",
            "Inteligências Artificiais",
            "Análise de Redação",
            "Cronograma de Estudo",
            "Tira Dúvidas e Resolução",
            "IA de Aceleração Cognitiva",
          ],
        },
        {
          title: "Extras",
          items: [
            "Inglês do Básico ao Avançado",
            "Suporte Prioritário",
            "Acesso a novas atualizações",
          ],
        },
      ],
      cta: "Começar agora",
      popular: true,
      link: "https://pay.kiwify.com.br/UaB4HNq",
    },
  ];

  return (
    <section id="planos" className="py-20 bg-muted/30 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,hsl(199,100%,40%,0.05),transparent_70%)]" />
      
      <div className="container relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Escolha o plano ideal <span className="text-gradient">para você</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Comece agora e transforme seus estudos. Cancele a qualquer momento.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto items-start">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              className={`relative p-6 rounded-2xl border transition-all duration-500 ${
                plan.popular 
                  ? "bg-card border-primary scale-105 z-10 shadow-[0_20px_50px_-12px_rgba(0,0,0,0.5),0_-4px_20px_-8px_rgba(0,136,204,0.15)] group" 
                  : "bg-card/50 border-border hover:border-primary/30"
              }`}
            >
              
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1 px-4 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                    Mais Popular
                  </span>
                </div>
              )}

              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  plan.popular ? "bg-gradient-primary" : "bg-muted"
                }`}>
                  <plan.icon className={`w-5 h-5 ${plan.popular ? "text-white" : "text-primary"}`} />
                </div>
                <div>
                  <h3 className="font-display font-bold text-lg">{plan.name}</h3>
                  <p className="text-xs text-muted-foreground">{plan.description}</p>
                </div>
              </div>

              <div className="mb-6 text-center">
                <div className="flex items-baseline gap-1 justify-center">
                  <span className="text-sm text-muted-foreground">R$</span>
                  <span className="font-display text-5xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">/mês</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{plan.billing}</p>
                {plan.originalPrice && (
                  <p className="text-xs text-secondary mt-1">
                    <span className="line-through text-muted-foreground">R${plan.originalPrice}/mês</span>
                    {" "}Economize 30%
                  </p>
                )}
              </div>

              <div className="space-y-4 mb-6">
                {plan.sections.map((section, sIdx) => (
                  <div key={sIdx}>
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">{section.title}</p>
                    <ul className="space-y-2">
                      {section.items.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm">
                          <ToggleIcon />
                          <span className="text-foreground/90">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              <Button 
                variant={plan.popular ? "default" : "hero"}
                className={`w-full ${plan.popular ? "bg-[#25D366] hover:bg-[#1fb855] text-white font-bold shadow-lg hover:shadow-xl relative overflow-hidden before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/30 before:to-transparent before:-translate-x-full before:animate-[shine_3s_ease-in-out_infinite]" : ""}`}
                size="lg"
                onClick={() => setSelectedPlan({ name: plan.name, link: plan.link })}
              >
                {plan.cta}
              </Button>
            </motion.div>
          ))}
        </div>

        {/* Checkout Popup */}
        <CheckoutPopup
          isOpen={!!selectedPlan}
          onClose={() => setSelectedPlan(null)}
          planName={selectedPlan?.name || ""}
          planLink={selectedPlan?.link || ""}
        />
      </div>
    </section>
  );
};
