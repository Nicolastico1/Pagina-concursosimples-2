import { motion } from "framer-motion";
import { Play, MousePointer, BookOpen, FileQuestion, BarChart3, Sparkles, GripHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { useEffect } from "react";

// Import subject images
import linguaPortuguesa2 from "@/assets/subjects/lingua_portuguesa_2.webp";
import quimica from "@/assets/subjects/quimica.webp";
import matematicaEar from "@/assets/subjects/matematica_ear.webp";
import linguaPortuguesa from "@/assets/subjects/lingua_portuguesa.webp";
import linguaInglesa from "@/assets/subjects/lingua_inglesa.webp";
import matematicaCfn from "@/assets/subjects/matematica_cfn.webp";
import historiaBrasil from "@/assets/subjects/historia_brasil.webp";
import fisicaCompleta from "@/assets/subjects/fisica_completa.webp";

// Import course icons
import espcex from "@/assets/courses/espcex.png";
import eam from "@/assets/courses/eam.webp";
import cfn from "@/assets/courses/cfn.webp";
import eear from "@/assets/courses/eear_new.png";
import esa from "@/assets/courses/esa.webp";

export const DemoSection = () => {
  // Course icons carousel
  const [emblaRefCourses] = useEmblaCarousel(
    { loop: true, align: "center" },
    [Autoplay({ delay: 4000, stopOnInteraction: false, stopOnMouseEnter: true })]
  );

  const features = [
    { icon: MousePointer, text: "Escolha seu concurso" },
    { icon: BookOpen, text: "Estude por disciplinas" },
    { icon: FileQuestion, text: "Resolva simulados reais" },
    { icon: BarChart3, text: "Acompanhe seu progresso" },
    { icon: Sparkles, text: "Use a IA a seu favor" },
  ];

  // All subjects for desktop single row
  const allSubjects = [
    linguaPortuguesa2,
    quimica,
    matematicaEar,
    linguaPortuguesa,
    linguaInglesa,
    matematicaCfn,
    historiaBrasil,
    fisicaCompleta,
  ];

  // Row 1 subjects for mobile (left to right)
  const subjectsRow1 = [
    linguaPortuguesa2,
    quimica,
    matematicaEar,
    linguaPortuguesa,
  ];

  // Row 2 subjects for mobile (right to left)
  const subjectsRow2 = [
    linguaInglesa,
    matematicaCfn,
    historiaBrasil,
    fisicaCompleta,
  ];

  // Desktop single row carousel
  const [emblaRefDesktop] = useEmblaCarousel(
    { loop: true, dragFree: true, align: "start" },
    [Autoplay({ delay: 2500, stopOnInteraction: false, stopOnMouseEnter: true })]
  );

  // Mobile row 1
  const [emblaRef1] = useEmblaCarousel(
    { loop: true, dragFree: true, align: "start" },
    [Autoplay({ delay: 2500, stopOnInteraction: false, stopOnMouseEnter: true })]
  );

  // Mobile row 2
  const [emblaRef2] = useEmblaCarousel(
    { loop: true, dragFree: true, align: "start", direction: "rtl" },
    [Autoplay({ delay: 3000, stopOnInteraction: false, stopOnMouseEnter: true })]
  );

  // Load Wistia scripts
  useEffect(() => {
    const playerScript = document.createElement('script');
    playerScript.src = 'https://fast.wistia.com/player.js';
    playerScript.async = true;
    document.head.appendChild(playerScript);

    const embedScript = document.createElement('script');
    embedScript.src = 'https://fast.wistia.com/embed/lrryxrfunb.js';
    embedScript.async = true;
    embedScript.type = 'module';
    document.head.appendChild(embedScript);

    return () => {
      document.head.removeChild(playerScript);
      document.head.removeChild(embedScript);
    };
  }, []);

  return (
    <section className="py-20 bg-background relative overflow-hidden">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/30 text-secondary text-sm font-medium mb-6">
            <Play className="w-4 h-4" />
            Veja na prática
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Uma plataforma que <span className="text-gradient">simplifica</span> seus estudos
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Navegue entre aulas, questões e simulados com apenas alguns cliques
          </p>
        </motion.div>

        {/* Wistia Video Embed */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-4xl mx-auto mb-12"
        >
          <div className="relative rounded-2xl overflow-hidden border border-border shadow-2xl">
            <style>
              {`
                wistia-player[media-id='lrryxrfunb']:not(:defined) {
                  background: center / contain no-repeat url('https://fast.wistia.com/embed/medias/lrryxrfunb/swatch');
                  display: block;
                  filter: blur(5px);
                  padding-top: 56.25%;
                }
              `}
            </style>
            {/* @ts-ignore */}
            <wistia-player media-id="lrryxrfunb" aspect="1.7777777777777777"></wistia-player>
          </div>
        </motion.div>

        {/* Feature pills - Desktop: wrapped, Mobile: marquee */}
        {/* Desktop version */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="hidden md:flex flex-wrap justify-center gap-3 mb-16"
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.1 * index }}
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border hover:border-primary/50 transition-colors"
            >
              <feature.icon className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">{feature.text}</span>
            </motion.div>
          ))}
        </motion.div>

        {/* Mobile version - Marquee effect */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="md:hidden mb-16 overflow-hidden"
        >
          <div className="relative">
            <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />
            
            <div className="flex animate-marquee">
              {[...features, ...features, ...features].map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 px-4 py-2 mx-2 rounded-full bg-card border border-border whitespace-nowrap flex-shrink-0"
                >
                  <feature.icon className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">{feature.text}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="flex justify-center mb-16"
        >
          <a href="#planos">
            <Button variant="hero" size="xl">
              Começar Treinamento
            </Button>
          </a>
        </motion.div>

        {/* Course icons with title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mb-8"
        >
          <div className="flex justify-center mb-6">
            <p className="text-center text-foreground font-semibold text-base sm:text-lg px-6 py-3 rounded-lg bg-primary/20 backdrop-blur-sm border border-primary/30">
              Escolha o concurso e comece sua preparação agora
            </p>
          </div>
          <div className="overflow-hidden max-w-xs mx-auto" ref={emblaRefCourses}>
            <div className="flex">
              {[espcex, eam, cfn, eear, esa].map((course, index) => (
                <div key={index} className="flex-shrink-0 w-full flex justify-center">
                  <img
                    src={course}
                    alt="Concurso disponível"
                    className="w-24 h-24 sm:w-28 sm:h-28 object-contain"
                  />
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Video lessons section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mb-8"
        >
          <p className="text-muted-foreground text-base sm:text-lg max-w-3xl mx-auto leading-relaxed">
            Na nossa área de membros você tem acesso a{" "}
            <span className="text-foreground font-semibold">vídeo aulas diretas e didáticas</span>{" "}
            pra você evoluir com{" "}
            <span className="text-primary font-semibold">clareza e sem enrolação</span>.
          </p>
        </motion.div>

        {/* Drag hint */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.6 }}
          className="flex items-center justify-center gap-2 text-muted-foreground text-sm mb-6"
        >
          <GripHorizontal className="w-4 h-4" />
          <span>Arraste para ver mais</span>
        </motion.div>

        {/* Desktop: Single row carousel */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="hidden md:block"
        >
          <div className="relative">
            <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />
            
            <div className="overflow-hidden cursor-grab active:cursor-grabbing" ref={emblaRefDesktop}>
              <div className="flex gap-4">
                {[...allSubjects, ...allSubjects, ...allSubjects].map((subject, index) => (
                  <div
                    key={index}
                    className="flex-shrink-0 w-56 lg:w-64"
                  >
                    <img
                      src={subject}
                      alt="Matéria disponível na plataforma"
                      className="w-full h-auto rounded-xl shadow-lg hover:scale-105 transition-transform duration-300"
                      draggable="false"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Mobile: Two rows with smaller cards */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="md:hidden space-y-3"
        >
          {/* Row 1 - Left to Right */}
          <div className="relative">
            <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />
            
            <div className="overflow-hidden cursor-grab active:cursor-grabbing" ref={emblaRef1}>
              <div className="flex gap-3">
                {[...subjectsRow1, ...subjectsRow1, ...subjectsRow1].map((subject, index) => (
                  <div
                    key={index}
                    className="flex-shrink-0 w-32 sm:w-36"
                  >
                    <img
                      src={subject}
                      alt="Matéria disponível na plataforma"
                      className="w-full h-auto rounded-lg shadow-md hover:scale-105 transition-transform duration-300"
                      draggable="false"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Row 2 - Right to Left */}
          <div className="relative" dir="rtl">
            <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />
            
            <div className="overflow-hidden cursor-grab active:cursor-grabbing" ref={emblaRef2}>
              <div className="flex gap-3">
                {[...subjectsRow2, ...subjectsRow2, ...subjectsRow2].map((subject, index) => (
                  <div
                    key={index}
                    className="flex-shrink-0 w-32 sm:w-36"
                    dir="ltr"
                  >
                    <img
                      src={subject}
                      alt="Matéria disponível na plataforma"
                      className="w-full h-auto rounded-lg shadow-md hover:scale-105 transition-transform duration-300"
                      draggable="false"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
