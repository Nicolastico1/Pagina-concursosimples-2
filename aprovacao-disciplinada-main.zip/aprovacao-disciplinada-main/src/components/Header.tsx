import { motion } from "framer-motion";
import logoCS from "@/assets/logo_concurso_simples.webp";

export const Header = () => {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border/50"
    >
      <div className="container flex items-center justify-between h-16">
        <a href="#" className="flex items-center">
          <img 
            src={logoCS} 
            alt="Concurso Simples" 
            className="h-10 md:h-12 w-auto object-contain"
          />
        </a>
        
        <nav className="hidden md:flex items-center gap-8">
          <a href="#como-funciona" className="text-muted-foreground hover:text-foreground transition-colors text-sm">
            Como Funciona
          </a>
          <a href="#planos" className="text-muted-foreground hover:text-foreground transition-colors text-sm">
            Planos
          </a>
          <a href="#faq" className="text-muted-foreground hover:text-foreground transition-colors text-sm">
            FAQ
          </a>
        </nav>

        <a
          href="#planos"
          className="hidden sm:inline-flex items-center justify-center h-10 px-6 rounded-lg bg-gradient-primary text-white font-semibold text-sm hover:scale-105 transition-transform"
        >
          Começar agora
        </a>
      </div>
    </motion.header>
  );
};
