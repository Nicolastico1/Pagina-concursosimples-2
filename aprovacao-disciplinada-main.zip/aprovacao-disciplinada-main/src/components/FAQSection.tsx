import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const FAQSection = () => {
  const faqs = [
    {
      question: "Para quem é a Concurso Simples?",
      answer: "A Concurso Simples é para qualquer pessoa que deseja passar em concursos militares como ESA, EsPCEx, EEAR, Marinha e outros. É ideal para quem busca organização, método e quer estudar de forma inteligente.",
    },
    {
      question: "Qual o diferencial da plataforma?",
      answer: "Somos 100% especializados em concursos militares. Oferecemos cronograma personalizado, simulados idênticos às provas reais, filtros de questões por assunto, gráficos de desempenho e inteligências artificiais que analisam seus erros e corrigem redações.",
    },
    {
      question: "Como funciona o suporte?",
      answer: "Oferecemos suporte via chat integrado na plataforma e por e-mail. No plano Combatente e Guerreiro, você tem acesso ao suporte prioritário com resposta em até 24 horas.",
    },
    {
      question: "Quais as formas de pagamento?",
      answer: "Aceitamos cartão de crédito (parcelado em até 12x) e Pix (com desconto especial). Todos os pagamentos são processados de forma segura.",
    },
    {
      question: "Como funciona o acesso após a assinatura?",
      answer: "Assim que o pagamento é confirmado, você recebe imediatamente o acesso à plataforma por e-mail. No caso do Pix, o acesso é liberado em poucos minutos após a confirmação.",
    },
    {
      question: "Posso cancelar a qualquer momento?",
      answer: "Sim! Você pode cancelar sua assinatura a qualquer momento, sem multa ou burocracia. Seu acesso permanece ativo até o final do período já pago.",
    },
  ];

  return (
    <section id="faq" className="py-20 bg-muted/30 relative">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Perguntas <span className="text-gradient">Frequentes</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Tire suas dúvidas sobre a Concurso Simples
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-3xl mx-auto"
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-card border border-border rounded-xl px-6 data-[state=open]:border-primary/50 transition-colors"
              >
                <AccordionTrigger className="text-left font-semibold hover:no-underline py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};
