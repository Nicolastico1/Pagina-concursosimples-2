import { motion } from "framer-motion";
import { useEffect, useCallback } from "react";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";

// Import testimonial images
import igorPe from "@/assets/testimonials/igor_pe.webp";
import thiagoRj from "@/assets/testimonials/thiago_rj.webp";
import alanRs from "@/assets/testimonials/alan_rs.webp";
import luanRj from "@/assets/testimonials/luan_rj.webp";
import nelitonRj from "@/assets/testimonials/neliton_rj.webp";
import samaraRr from "@/assets/testimonials/samara_rr.webp";
import gabrielMg from "@/assets/testimonials/gabriel_mg.webp";
import lucasRj from "@/assets/testimonials/lucas_rj.webp";

const testimonialImages = [
  { src: igorPe, alt: "Depoimento Igor Luan - Aprovado na EAM - Olinda/PE" },
  { src: thiagoRj, alt: "Depoimento Thiago Ricardo - Aprovado na EAM - Rio de Janeiro/RJ" },
  { src: alanRs, alt: "Depoimento SG. Alan Faria - Aprovado na ESA - Cachoeira do Sul/RS" },
  { src: luanRj, alt: "Depoimento Luan Souza - Aprovado na CFN - Duque de Caxias/RJ" },
  { src: nelitonRj, alt: "Depoimento Neliton Medeiros - Aprovado na ESA - São João de Meriti/RJ" },
  { src: samaraRr, alt: "Depoimento Samara Ramos - Aprovada na ESA - Boa Vista/RR" },
  { src: gabrielMg, alt: "Depoimento Gabriel Gomes - Aprovado na ESA - Itajubá/MG" },
  { src: lucasRj, alt: "Depoimento Lucas Pacheco - Aprovado na CFN - Niterói/RJ" },
];

export const TestimonialsSection = () => {
  const [emblaRef, emblaApi] = useEmblaCarousel(
    {
      loop: true,
      align: "start",
      slidesToScroll: 1,
      dragFree: true,
      containScroll: false,
    },
    [
      Autoplay({
        delay: 3000,
        stopOnInteraction: false,
        stopOnMouseEnter: true,
      }),
    ]
  );

  const onPointerDown = useCallback(() => {
    if (emblaApi) emblaApi.plugins().autoplay?.stop();
  }, [emblaApi]);

  const onPointerUp = useCallback(() => {
    if (emblaApi) emblaApi.plugins().autoplay?.play();
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;

    emblaApi.on("pointerDown", onPointerDown);
    emblaApi.on("pointerUp", onPointerUp);

    return () => {
      emblaApi.off("pointerDown", onPointerDown);
      emblaApi.off("pointerUp", onPointerUp);
    };
  }, [emblaApi, onPointerDown, onPointerUp]);

  return (
    <section className="py-20 bg-muted/30 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,hsl(166,100%,30%,0.05),transparent_70%)]" />

      <div className="container relative mb-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Quem usa, <span className="text-gradient">recomenda</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Veja o que a atriz mundialmente reconhecida está dizendo sobre nós
          </p>
        </motion.div>
      </div>

      {/* Carousel - Full width */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="relative"
      >
        {/* Gradient overlays for fade effect */}
        <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-32 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />

        <div 
          className="overflow-hidden cursor-grab active:cursor-grabbing" 
          ref={emblaRef}
        >
          <div className="flex gap-4 sm:gap-6">
            {testimonialImages.map((testimonial, index) => (
              <div
                key={index}
                className="flex-shrink-0 pl-4 first:pl-8 last:pr-8"
              >
                <div className="relative group">
                  <img
                    src={testimonial.src}
                    alt={testimonial.alt}
                    className="w-[280px] sm:w-[320px] md:w-[380px] h-auto rounded-2xl shadow-lg transition-transform duration-300 group-hover:scale-[1.02] select-none pointer-events-none"
                    draggable={false}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Drag hint */}
        <p className="text-center text-muted-foreground/60 text-sm mt-6">
          <span className="inline-flex items-center gap-2">
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M14 4h6v6M10 20H4v-6M21 3l-7 7M3 21l7-7" />
            </svg>
            Arraste para ver mais depoimentos
          </span>
        </p>
      </motion.div>
    </section>
  );
};
