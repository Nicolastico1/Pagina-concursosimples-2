import { motion } from "framer-motion";
import { Shield, FileCheck, RefreshCcw } from "lucide-react";

export const GuaranteeSection = () => {
  return (
    <section className="py-20 bg-background relative">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto"
        >
          <div className="relative p-8 md:p-12 rounded-3xl bg-gradient-to-br from-secondary/10 via-card to-primary/10 border border-secondary/30 overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-secondary/10 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
            
            <div className="relative text-center">
              <motion.div
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2, type: "spring" }}
                className="w-20 h-20 rounded-full bg-gradient-primary flex items-center justify-center mx-auto mb-6 shadow-lg glow-primary"
              >
                <Shield className="w-10 h-10 text-white" />
              </motion.div>

              <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4">
                Garantia de <span className="text-gradient">7 dias</span>
              </h2>
              
              <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
                Teste a plataforma por 7 dias. Se não ficar satisfeito por qualquer motivo, 
                devolvemos 100% do seu dinheiro. Sem perguntas, sem burocracia.
              </p>

              <div className="flex items-center justify-center gap-2">
                <RefreshCcw className="w-5 h-5 text-primary" />
                <span className="text-sm">Reembolso total</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
