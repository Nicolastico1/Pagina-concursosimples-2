import { motion } from "framer-motion";
import { Shield, Target, Brain, TrendingUp, Clock, CheckCircle2 } from "lucide-react";

export const WhyItWorksSection = () => {
  const reasons = [
    {
      icon: Shield,
      title: "Especializada em concursos militares",
      description: "Conteúdo 100% focado em ESA, EsPCEx, EEAR, Marinha e outros",
    },
    {
      icon: Target,
      title: "Foco no que realmente cai",
      description: "Questões e aulas baseadas no histórico real das provas",
    },
    {
      icon: Clock,
      title: "Organiza seus estudos",
      description: "Cronograma personalizado para sua rotina e prazo",
    },
    {
      icon: Brain,
      title: "IA que corrige seus erros",
      description: "Análise inteligente de desempenho e recomendações personalizadas",
    },
    {
      icon: TrendingUp,
      title: "Treino como no dia da prova",
      description: "Simulados com tempo real e condições idênticas ao concurso",
    },
    {
      icon: CheckCircle2,
      title: "Acompanhamento visual",
      description: "Gráficos de evolução que mostram seu progresso diário",
    },
  ];

  return (
    <section className="py-20 bg-muted/30 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,hsl(199,100%,40%,0.05),transparent_70%)]" />
      
      <div className="container relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Por que isso <span className="text-gradient">funciona</span>?
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Um método comprovado por milhares de aprovados
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((reason, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              className="group p-6 rounded-2xl bg-card/50 border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <reason.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-display font-semibold text-lg mb-2">
                {reason.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {reason.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
