import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, Lock, User, Mail, Phone } from "lucide-react";
import { z } from "zod";
import logoCheckout from "@/assets/logo_checkout.png";
import { supabase } from "@/integrations/supabase/client";

const checkoutSchema = z.object({
  name: z.string().trim().min(2, "Nome deve ter pelo menos 2 caracteres").max(100),
  email: z.string().trim().email("E-mail inválido").max(255),
  phone: z
    .string()
    .trim()
    .max(20)
    .refine(
      (value) => {
        const digits = value.replace(/\D/g, "");
        return digits.length === 10 || digits.length === 11;
      },
      { message: "WhatsApp inválido" }
    ),
});

interface CheckoutPopupProps {
  isOpen: boolean;
  onClose: () => void;
  planName: string;
  planLink: string;
}

export const CheckoutPopup = ({ isOpen, onClose, planName, planLink }: CheckoutPopupProps) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    if (numbers.length <= 11) return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhone(e.target.value);
    setFormData({ ...formData, phone: formatted });
  };

  const sendLeadToWebhook = async (leadData: {
    id: string;
    name: string;
    email: string;
    phone: string;
    plan_name: string;
    created_at: string;
  }) => {
    try {
      const { error } = await supabase.functions.invoke("send-lead-webhook", {
        body: leadData,
      });
      if (error) {
        console.error("Webhook error:", error);
      } else {
        console.log("Lead sent to Google Sheets successfully");
      }
    } catch (err) {
      console.error("Error sending lead to webhook:", err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrors({});

    const result = checkoutSchema.safeParse(formData);

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        if (err.path[0]) {
          fieldErrors[err.path[0] as string] = err.message;
        }
      });
      setErrors(fieldErrors);
      setIsSubmitting(false);
      return;
    }

    if (!planLink) {
      setErrors({ submit: "Link do checkout indisponível. Tente novamente." });
      setIsSubmitting(false);
      return;
    }

    const name = formData.name.trim();
    const email = formData.email.trim();
    const phoneDigits = formData.phone.replace(/\D/g, "");
    
    // Format phone with country code: +55 DDD XXXXX-XXXX
    const formattedPhone = phoneDigits.length >= 10
      ? `+55 ${phoneDigits.slice(0, 2)} ${phoneDigits.slice(2, 7)}-${phoneDigits.slice(7)}`
      : phoneDigits;
    
    const leadId = crypto.randomUUID();
    const createdAt = new Date().toISOString();

    // Open the checkout tab synchronously to avoid popup blockers.
    const checkoutTab = window.open("about:blank", "_blank");

    // Send lead to Google Sheets webhook (async, non-blocking)
    sendLeadToWebhook({
      id: leadId,
      name,
      email,
      phone: formattedPhone,
      plan_name: planName,
      created_at: createdAt,
    });

    // Save lead data to database (async, non-blocking)
    supabase.from("checkout_leads").insert({
      name,
      email,
      phone: formattedPhone,
      plan_name: planName,
    }).then(({ error }) => {
      if (error) {
        console.error("Database error:", error);
      }
    });

    // Capture UTM parameters from current URL.
    // Regra: as 5 UTMs abaixo DEVEM sempre existir na URL final, mesmo vazias (utm_param=)
    const searchParams = new URLSearchParams(window.location.search);
    // Fallback: alguns tráfegos colocam UTMs após "#" (ex: /#/?utm_source=...)
    const hashQuery = window.location.hash.includes("?") ? window.location.hash.split("?")[1] : "";
    const hashParams = new URLSearchParams(hashQuery);

    const requiredUtmKeys = [
      "utm_source",
      "utm_campaign",
      "utm_medium",
      "utm_content",
      "utm_term",
    ] as const;

    const getUtm = (key: (typeof requiredUtmKeys)[number]) =>
      searchParams.get(key) ?? hashParams.get(key) ?? "";

    const utmParams: Record<string, string> = {};
    requiredUtmKeys.forEach((key) => {
      utmParams[key] = getUtm(key);
    });

    // Fire Meta Pixel InitiateCheckout event
    if (typeof window !== 'undefined' && (window as any).fbq) {
      (window as any).fbq('track', 'InitiateCheckout', {
        content_name: planName,
        content_category: 'Plano',
        currency: 'BRL',
      });
    }

    // Build URL with pre-populated data and UTM parameters
    const redirectUrl = (() => {
      const serializeParams = (params: URLSearchParams) => {
        // Força serialização "key=value" (mesmo vazio) para compatibilidade Kiwify/UTMfy
        const parts: string[] = [];
        params.forEach((value, key) => {
          parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
        });
        return parts.join("&");
      };

      try {
        const url = new URL(planLink, window.location.origin);

        const finalParams = new URLSearchParams(url.search);
        finalParams.set("name", name);
        finalParams.set("email", email);
        finalParams.set("phone", phoneDigits);
        finalParams.set("whatsapp", phoneDigits);

        requiredUtmKeys.forEach((key) => {
          finalParams.set(key, utmParams[key] ?? "");
        });

        const query = serializeParams(finalParams);
        url.search = query ? `?${query}` : "";
        return url.toString();
      } catch {
        const params = new URLSearchParams();
        params.set("name", name);
        params.set("email", email);
        params.set("phone", phoneDigits);
        params.set("whatsapp", phoneDigits);
        requiredUtmKeys.forEach((key) => {
          params.set(key, utmParams[key] ?? "");
        });

        const query = serializeParams(params);
        return `${planLink}${planLink.includes("?") ? "&" : "?"}${query}`;
      }
    })();

    // Redirect to checkout
    if (checkoutTab) {
      checkoutTab.location.href = redirectUrl;
    } else {
      // Fallback when popup was blocked
      window.location.href = redirectUrl;
    }

    // Reset form and close popup
    setFormData({ name: "", email: "", phone: "" });
    setIsSubmitting(false);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-md z-50"
          />
          
          {/* Popup - Centered */}
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              transition={{ type: "spring", duration: 0.5, bounce: 0.3 }}
              className="w-full max-w-md"
            >
              <div className="relative bg-gradient-to-b from-card to-card/95 border border-primary/20 rounded-3xl shadow-[0_25px_50px_-12px_rgba(0,136,204,0.25)] overflow-hidden">
                {/* Decorative top gradient */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-primary" />
                
                {/* Close button */}
                <button
                  onClick={onClose}
                  className="absolute top-4 right-4 w-10 h-10 rounded-full bg-muted/50 border border-border/50 flex items-center justify-center hover:bg-muted transition-all duration-200 hover:scale-105 z-10"
                >
                  <X className="w-5 h-5 text-muted-foreground" />
                </button>

                <div className="p-8">
                  {/* Header */}
                  <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 border border-primary/30 mb-4 overflow-hidden">
                    <img src={logoCheckout} alt="Logo" className="w-12 h-12 object-contain" />
                  </div>
                    <h3 className="font-display text-2xl font-bold mb-2">Finalizar Inscrição</h3>
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-secondary/10 border border-secondary/30">
                      <span className="text-sm font-medium text-secondary">Plano {planName}</span>
                    </div>
                  </div>

                  {/* Form */}
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-sm font-medium flex items-center gap-2">
                        <User className="w-4 h-4 text-primary" />
                        Nome completo
                      </Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Digite seu nome completo"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className={`h-12 bg-muted/30 border-border/50 rounded-xl focus:border-primary focus:ring-primary/20 transition-all ${errors.name ? "border-destructive focus:border-destructive" : ""}`}
                      />
                      {errors.name && (
                        <p className="text-xs text-destructive flex items-center gap-1">
                          <span className="w-1 h-1 rounded-full bg-destructive" />
                          {errors.name}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-sm font-medium flex items-center gap-2">
                        <Mail className="w-4 h-4 text-primary" />
                        E-mail
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="seu@email.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className={`h-12 bg-muted/30 border-border/50 rounded-xl focus:border-primary focus:ring-primary/20 transition-all ${errors.email ? "border-destructive focus:border-destructive" : ""}`}
                      />
                      {errors.email && (
                        <p className="text-xs text-destructive flex items-center gap-1">
                          <span className="w-1 h-1 rounded-full bg-destructive" />
                          {errors.email}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-sm font-medium flex items-center gap-2">
                        <Phone className="w-4 h-4 text-primary" />
                        Telefone / WhatsApp
                      </Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="(00) 00000-0000"
                        value={formData.phone}
                        onChange={handlePhoneChange}
                        className={`h-12 bg-muted/30 border-border/50 rounded-xl focus:border-primary focus:ring-primary/20 transition-all ${errors.phone ? "border-destructive focus:border-destructive" : ""}`}
                      />
                      {errors.phone && (
                        <p className="text-xs text-destructive flex items-center gap-1">
                          <span className="w-1 h-1 rounded-full bg-destructive" />
                          {errors.phone}
                        </p>
                      )}
                    </div>

                    <Button
                      type="submit"
                      className="w-full h-14 bg-gradient-to-r from-secondary to-secondary/90 hover:from-secondary/90 hover:to-secondary text-white font-bold text-lg rounded-xl shadow-lg shadow-secondary/25 hover:shadow-xl hover:shadow-secondary/30 transition-all duration-300 relative overflow-hidden group"
                      disabled={isSubmitting}
                    >
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        {isSubmitting ? (
                          <>
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                            />
                            Redirecionando...
                          </>
                        ) : (
                          <>Continuar para pagamento</>
                        )}
                      </span>
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                    </Button>

                    {errors.submit && (
                      <p className="text-sm text-destructive text-center">{errors.submit}</p>
                    )}

                    <div className="flex items-center justify-center gap-2 pt-2">
                      <Lock className="w-4 h-4 text-muted-foreground" />
                      <p className="text-xs text-muted-foreground">
                        Seus dados estão seguros e protegidos
                      </p>
                    </div>
                  </form>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
};
