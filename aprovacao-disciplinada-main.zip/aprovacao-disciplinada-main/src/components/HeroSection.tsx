import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { X, Check, BookOpen, BarChart3, Calendar, Brain, Star, Headphones, ShieldCheck, ChevronDown } from "lucide-react";
import antesImage from "@/assets/hero/antes.jpeg";
import depoisImage from "@/assets/hero/depois.jpeg";
import aprovado1 from "@/assets/hero/aprovado1.jpeg";
import aprovado2 from "@/assets/hero/aprovado2.jpeg";
import aprovado3 from "@/assets/hero/aprovado3.jpeg";
import aprovado4 from "@/assets/hero/aprovado4.png";

export const HeroSection = () => {
  return (
    <section className="relative min-h-screen pt-24 pb-16 overflow-hidden bg-gradient-hero">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl" />
      </div>

      <div className="container relative z-10">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 mb-6"
          >
            <span className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
            <span className="text-sm text-muted-foreground">
              Especializado em Concursos Militares
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display text-3xl sm:text-4xl md:text-5xl font-bold leading-tight mb-6"
          >
            Os aprovados de 2026 já começaram. <br className="hidden sm:block" /><span className="text-gradient">Você vai ficar para trás?</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-base sm:text-lg text-muted-foreground max-w-3xl mx-auto mb-8"
          >
            Seu concorrente já sabe o que vai cair na prova com estratégia, cronograma e foco total na aprovação. <span className="text-foreground font-medium">Faça parte agora da Missão Aprovados de Elite</span> e escolha o concurso que você quer vencer: <span className="text-foreground font-semibold">ESA, EEAR, CFN, EsPCEx ou EAM.</span>
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <a href="#planos">
              <Button variant="hero" size="xl">
                Começar Treinamento
              </Button>
            </a>
          </motion.div>

          {/* Social Proof Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-8 flex flex-col items-center gap-6"
          >
            {/* Access info */}
            <p className="text-muted-foreground text-sm">
              Acesso imediato • Conteúdo 2026
            </p>

            {/* Avatars + Stats */}
            <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
              {/* Avatar stack */}
              <div className="flex -space-x-3">
                {[aprovado1, aprovado2, aprovado3, aprovado4].map((avatar, index) => (
                  <img
                    key={index}
                    src={avatar}
                    alt={`Aluno aprovado ${index + 1}`}
                    className="w-10 h-10 rounded-full border-2 border-background object-cover"
                  />
                ))}
              </div>

              {/* Approved students */}
              <div className="flex items-center gap-2">
                <span className="text-foreground font-semibold">+5000 alunos aprovados</span>
                <div className="w-px h-6 bg-border hidden sm:block" />
              </div>

              {/* Rating */}
              <div className="flex items-center gap-1.5">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <span className="text-foreground font-semibold">4.9/5</span>
              </div>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap justify-center gap-6 sm:gap-8 mt-2">
              <div className="flex items-center gap-2 text-secondary">
                <Headphones className="w-5 h-5" />
                <span className="text-foreground font-medium">Suporte 24h</span>
              </div>
              <div className="flex items-center gap-2 text-secondary">
                <ShieldCheck className="w-5 h-5" />
                <span className="text-foreground font-medium">Pagamento Seguro</span>
              </div>
              <div className="flex items-center gap-2 text-secondary">
                <ShieldCheck className="w-5 h-5" />
                <span className="text-foreground font-medium">Garantia 7 dias</span>
              </div>
            </div>

            {/* Scroll indicator */}
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
              className="mt-4"
            >
              <ChevronDown className="w-6 h-6 text-secondary" />
            </motion.div>
          </motion.div>
        </div>

        {/* Before/After Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="grid md:grid-cols-2 gap-6 lg:gap-12 max-w-5xl mx-auto mt-16"
        >
          {/* Before Card */}
          <div className="relative group rounded-2xl overflow-hidden border border-border/50 bg-card/50 backdrop-blur-sm shadow-xl">
            {/* Before Image */}
            <div className="relative aspect-[4/3] overflow-hidden">
              <img 
                src={antesImage} 
                alt="Antes - Estudante frustrado" 
                className="w-full h-full object-cover object-center"
                loading="eager"
                decoding="async"
              />
              {/* Gradient overlay for smooth transition */}
              <div className="absolute inset-0 bg-gradient-to-t from-card via-card/60 to-transparent" />
              
              {/* Label positioned on top of image */}
              <div className="absolute top-4 left-4 z-10">
                <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-destructive/90 border border-destructive text-white text-sm font-bold shadow-lg backdrop-blur-sm">
                  <X className="w-4 h-4" />
                  ANTES
                </span>
              </div>
            </div>
            
            <div className="relative p-6 -mt-16 z-10">
              <div className="relative space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-destructive/20 flex items-center justify-center shrink-0 border border-destructive/30">
                    <BookOpen className="w-5 h-5 text-destructive" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Materiais bagunçados</h4>
                    <p className="text-sm text-muted-foreground">PDFs soltos, vídeos espalhados, sem saber por onde começar</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-destructive/20 flex items-center justify-center shrink-0 border border-destructive/30">
                    <Calendar className="w-5 h-5 text-destructive" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Sem cronograma</h4>
                    <p className="text-sm text-muted-foreground">Estudando sem rumo, perdendo tempo com o que não cai</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-destructive/20 flex items-center justify-center shrink-0 border border-destructive/30">
                    <BarChart3 className="w-5 h-5 text-destructive" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Sem feedback</h4>
                    <p className="text-sm text-muted-foreground">Não sabe onde está errando, reprovação após reprovação</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* After Card */}
          <div className="relative group rounded-2xl overflow-hidden border border-primary/30 bg-card/50 backdrop-blur-sm shadow-xl ring-2 ring-primary/20">
            {/* After Image */}
            <div className="relative aspect-[4/3] overflow-hidden">
              <img 
                src={depoisImage} 
                alt="Depois - Militar aprovado" 
                className="w-full h-full object-cover object-top"
                loading="eager"
                decoding="async"
              />
              {/* Gradient overlay for smooth transition */}
              <div className="absolute inset-0 bg-gradient-to-t from-card via-card/60 to-transparent" />
              
              {/* Label positioned on top of image */}
              <div className="absolute top-4 left-4 z-10">
                <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-secondary/90 border border-secondary text-white text-sm font-bold shadow-lg backdrop-blur-sm">
                  <Check className="w-4 h-4" />
                  DEPOIS
                </span>
              </div>
            </div>
            
            <div className="relative p-6 -mt-16 z-10">
              <div className="relative space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center shrink-0 border border-primary/30">
                    <BookOpen className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Plataforma organizada</h4>
                    <p className="text-sm text-muted-foreground">Tudo em um só lugar: aulas, apostilas e questões</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center shrink-0 border border-primary/30">
                    <Calendar className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">Cronograma inteligente</h4>
                    <p className="text-sm text-muted-foreground">Sabe exatamente o que estudar cada dia até a prova</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-secondary/20 flex items-center justify-center shrink-0 border border-secondary/30">
                    <Brain className="w-5 h-5 text-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">IA corrigindo seus erros</h4>
                    <p className="text-sm text-muted-foreground">Simulados reais + análise inteligente do seu desempenho</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
