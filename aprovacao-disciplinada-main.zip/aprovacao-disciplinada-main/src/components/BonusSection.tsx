import { motion } from "framer-motion";
import { Gift } from "lucide-react";

import eliteAprovacao from "@/assets/bonus/elite_aprovacao.webp";
import suporteEspecializado from "@/assets/bonus/suporte_especializado.webp";
import planoEstudos from "@/assets/bonus/plano_estudos.webp";

const bonuses = [
  {
    id: 1,
    label: "Bônus 1",
    title: "Elite da Aprovação",
    description: "Você receberá uma mentoria durante 4 meses diretamente comigo e com minha equipe, com convidados da Elite das Forças Armadas, Master Coach palestrante do Tedex e um Mestre em Neurociência com tudo que você precisa para te ajudar alcançar sua aprovação.",
    extra: "Tenha acesso aos segredos nunca antes revelados, somente aqui na CS.",
    normalPrice: "R$1.997,00",
    currentPrice: "Grátis",
    image: eliteAprovacao,
  },
  {
    id: 2,
    label: "Bônus 2",
    title: "Plano de Estudos Infalível",
    description: "Você ainda receberá um Plano Infalível de Estudos para destravar seu aprendizado, onde os seus resultados nas provas objetiva nunca mais serão o mesmo.",
    extra: null,
    normalPrice: "R$597,00",
    currentPrice: "Grátis",
    image: planoEstudos,
  },
  {
    id: 3,
    label: "Bônus 3",
    title: "Suporte Especializado",
    description: "Imagine ter uma equipe de especialistas ao seu lado, pronta para te ajudar com as necessidades da plataforma em sua jornada. Aqui, você não estará sozinho(a)! Estamos prontos para responder suas dúvidas sobre a plataforma e remover qualquer obstáculo que possa surgir.",
    extra: null,
    normalPrice: "Incalculável",
    currentPrice: "Grátis",
    image: suporteEspecializado,
  },
];

export const BonusSection = () => {
  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="container mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Gift className="w-8 h-8 text-primary" />
            <span className="text-primary font-semibold text-lg">Bônus Exclusivos</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            E tem mais!
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Ao se inscrever hoje, você ainda ganha esses bônus incríveis
          </p>
        </motion.div>

        <div className="flex flex-col gap-8">
          {bonuses.map((bonus, index) => (
            <motion.div
              key={bonus.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-card rounded-2xl overflow-hidden border border-border/50 shadow-lg"
            >
              <div className="flex flex-col md:flex-row">
                <div className="md:w-2/5 flex-shrink-0 bg-background/50">
                  <img
                    src={bonus.image}
                    alt={bonus.title}
                    className="w-full h-64 md:h-full object-contain"
                  />
                </div>
                <div className="p-6 md:p-8 flex flex-col justify-center md:w-3/5">
                  <span className="text-primary font-semibold text-sm mb-2">
                    {bonus.label}
                  </span>
                  <h3 className="text-2xl md:text-3xl font-bold mb-4 text-foreground">
                    {bonus.title}
                  </h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {bonus.description}
                  </p>
                  {bonus.extra && (
                    <p className="text-primary font-medium mb-4 italic">
                      {bonus.extra}
                    </p>
                  )}
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 mt-auto pt-4 border-t border-border/50">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground line-through text-sm">
                        Valor normal: {bonus.normalPrice}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-foreground font-medium">Somente Hoje:</span>
                      <span className="text-primary font-bold text-xl">
                        {bonus.currentPrice}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
