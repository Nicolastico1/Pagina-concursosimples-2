import { motion } from "framer-motion";
import { MousePointer, BookOpen, FileQuestion, BarChart3, Brain, Trophy } from "lucide-react";
import dashboardMockup from "@/assets/dashboard_mockup.png";

export const HowItWorksSection = () => {
  const steps = [
    {
      number: "01",
      icon: MousePointer,
      title: "Escolha seu concurso",
      description: "Selecione ESA, EsPCEx, EEAR, Marinha ou outro concurso militar",
      color: "primary",
    },
    {
      number: "02",
      icon: BookOpen,
      title: "Acesse o conteúdo completo",
      description: "Videoaulas, apostilas e materiais organizados por disciplina",
      color: "primary",
    },
    {
      number: "03",
      icon: FileQuestion,
      title: "Treine com questões reais",
      description: "Banco com milhares de questões filtradas por assunto e dificuldade",
      color: "secondary",
    },
    {
      number: "04",
      icon: BarChart3,
      title: "Acompanhe seu progresso",
      description: "Gráficos de desempenho que mostram sua evolução em tempo real",
      color: "secondary",
    },
    {
      number: "05",
      icon: Brain,
      title: "Corrija seus erros com IA",
      description: "Receba análises personalizadas e recomendações inteligentes",
      color: "primary",
    },
    {
      number: "06",
      icon: Trophy,
      title: "Conquiste sua aprovação",
      description: "Chegue preparado e confiante no dia da prova",
      color: "secondary",
    },
  ];

  return (
    <section id="como-funciona" className="py-20 bg-background relative overflow-hidden">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 text-primary text-sm font-medium mb-6">
            Simples e Rápido
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Como <span className="text-gradient">funciona</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Em poucos passos, transforme seus estudos em aprovação
          </p>

          {/* Dashboard mockup with floating animation */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-10 mb-4"
          >
            <motion.img
              src={dashboardMockup}
              alt="Dashboard do Concurso Simples mostrando estatísticas de desempenho"
              className="w-full max-w-md mx-auto rounded-2xl drop-shadow-2xl"
              animate={{
                y: [0, -12, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </motion.div>
        </motion.div>

        <div className="relative max-w-4xl mx-auto">
          {/* Vertical line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-border hidden sm:block" />

          <div className="space-y-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 * index }}
                className={`relative flex items-start gap-6 ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                {/* Step indicator */}
                <div className="absolute left-8 md:left-1/2 -translate-x-1/2 z-10">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg ${
                    step.color === "primary" 
                      ? "bg-gradient-to-br from-primary to-primary/80 glow-primary" 
                      : "bg-gradient-to-br from-secondary to-secondary/80 glow-secondary"
                  }`}>
                    <step.icon className="w-7 h-7 text-white" />
                  </div>
                </div>

                {/* Content card */}
                <div className={`flex-1 ml-20 md:ml-0 ${index % 2 === 0 ? "md:pr-24 md:text-right" : "md:pl-24"}`}>
                  <div className="p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-colors">
                    <span className="inline-block text-xs font-bold text-primary mb-2">{step.number}</span>
                    <h3 className="font-display font-bold text-xl mb-2">{step.title}</h3>
                    <p className="text-muted-foreground text-sm">{step.description}</p>
                  </div>
                </div>

                {/* Spacer for alternating layout */}
                <div className="hidden md:block flex-1" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
