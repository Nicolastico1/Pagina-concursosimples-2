import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Mail } from "lucide-react";
import { Link } from "react-router-dom";
import logoCS from "@/assets/logo_concurso_simples.webp";

export const Footer = () => {
  return (
    <footer className="relative bg-background border-t border-border">
      {/* Final CTA */}
      <div className="container py-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="text-muted-foreground text-lg mb-2">
            Agora que você tirou todas as dúvidas...
          </p>
          <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4">
            Está pronto para conquistar sua <span className="text-gradient">aprovação</span>?
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
            Você já viu tudo o que vai receber. Agora é a hora de dar o primeiro passo rumo ao seu sucesso. Sua carreira militar está a um clique de distância.
          </p>
          <p className="text-xl mb-6">
            👇 Toque no botão abaixo e garanta seu acesso imediato: 👇
          </p>
          <a href="#planos">
            <Button variant="hero" size="xl">
              Começar Treinamento
            </Button>
          </a>
        </motion.div>
      </div>

      {/* Footer content */}
      <div className="border-t border-border">
        <div className="container py-12">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="lg:col-span-2">
              <a href="#" className="flex items-center mb-4">
                <img 
                  src={logoCS} 
                  alt="Concurso Simples" 
                  className="h-10 w-auto object-contain"
                />
              </a>
              <p className="text-muted-foreground text-sm max-w-sm">
                A plataforma especializada em concursos militares que organiza seus estudos 
                e acelera sua aprovação com método, tecnologia e inteligência artificial.
              </p>
            </div>

            {/* Links */}
            <div>
              <h4 className="font-semibold mb-4">Links</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#como-funciona" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Como Funciona
                  </a>
                </li>
                <li>
                  <a href="#planos" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Planos
                  </a>
                </li>
                <li>
                  <a href="#faq" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-3">
                <li>
                  <a href="mailto:suporte@concursosimples.com.br" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                    <Mail className="w-4 h-4" />
                    suporte@concursosimples.com.br
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-border">
          <div className="container py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-muted-foreground">
              © 2024 Concurso Simples. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-4">
              <Link to="/termos-de-uso" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                Termos de Uso
              </Link>
              <Link to="/politica-de-privacidade" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                Política de Privacidade
              </Link>
            </div>
          </div>
        </div>

        {/* Facebook Disclaimer */}
        <div className="border-t border-border/50">
          <div className="container py-4">
            <p className="text-[10px] text-muted-foreground/60 text-center leading-relaxed">
              Este site não pertence ao Facebook e não tem nenhuma ligação ou afiliação com a empresa do Facebook, todo conteúdo postado nessa página é de total responsabilidade da Concurso Simples
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};
