-- Ensure the rate limit trigger exists (idempotent recreation)
DROP TRIGGER IF EXISTS checkout_leads_rate_limit ON public.checkout_leads;

CREATE TRIGGER checkout_leads_rate_limit
  BEFORE INSERT ON public.checkout_leads
  FOR EACH ROW
  EXECUTE FUNCTION public.check_checkout_rate_limit();