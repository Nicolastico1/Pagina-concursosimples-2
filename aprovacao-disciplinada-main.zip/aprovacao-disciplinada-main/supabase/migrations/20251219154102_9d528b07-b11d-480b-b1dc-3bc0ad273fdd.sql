-- Add unique constraint on email to prevent duplicate leads
ALTER TABLE public.checkout_leads ADD CONSTRAINT checkout_leads_email_unique UNIQUE (email);