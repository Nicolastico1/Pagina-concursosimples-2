-- Create a function to check rate limit for checkout leads
CREATE OR REPLACE FUNCTION public.check_checkout_rate_limit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  recent_count INTEGER;
BEGIN
  -- Count inserts in the last hour with the same email or phone
  SELECT COUNT(*) INTO recent_count
  FROM public.checkout_leads
  WHERE (email = NEW.email OR phone = NEW.phone)
    AND created_at > NOW() - INTERVAL '1 hour';
  
  -- Allow max 3 submissions per email/phone per hour
  IF recent_count >= 3 THEN
    RAISE EXCEPTION 'Rate limit exceeded. Please try again later.';
  END IF;
  
  -- Also limit total inserts per minute to prevent mass spam
  SELECT COUNT(*) INTO recent_count
  FROM public.checkout_leads
  WHERE created_at > NOW() - INTERVAL '1 minute';
  
  -- Allow max 10 total submissions per minute
  IF recent_count >= 10 THEN
    RAISE EXCEPTION 'Too many requests. Please try again in a moment.';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to enforce rate limiting
CREATE TRIGGER checkout_leads_rate_limit
  BEFORE INSERT ON public.checkout_leads
  FOR EACH ROW
  EXECUTE FUNCTION public.check_checkout_rate_limit();