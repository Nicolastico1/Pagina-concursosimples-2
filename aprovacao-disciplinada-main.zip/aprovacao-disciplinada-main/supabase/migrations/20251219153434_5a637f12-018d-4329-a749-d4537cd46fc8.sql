-- Create table for checkout leads
CREATE TABLE public.checkout_leads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  plan_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.checkout_leads ENABLE ROW LEVEL SECURITY;

-- Allow public inserts (for lead capture before authentication)
CREATE POLICY "Anyone can insert checkout leads"
ON public.checkout_leads
FOR INSERT
WITH CHECK (true);

-- Only allow reading through backend/admin (no public read access)
CREATE POLICY "No public read access"
ON public.checkout_leads
FOR SELECT
USING (false);