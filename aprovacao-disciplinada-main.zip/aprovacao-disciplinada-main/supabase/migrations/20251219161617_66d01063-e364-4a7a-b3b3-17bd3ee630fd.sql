-- Drop the restrictive INSERT policy
DROP POLICY IF EXISTS "Anyone can insert checkout leads" ON public.checkout_leads;

-- Create a new PERMISSIVE INSERT policy
CREATE POLICY "Anyone can insert checkout leads"
ON public.checkout_leads
FOR INSERT
TO anon, authenticated
WITH CHECK (true);