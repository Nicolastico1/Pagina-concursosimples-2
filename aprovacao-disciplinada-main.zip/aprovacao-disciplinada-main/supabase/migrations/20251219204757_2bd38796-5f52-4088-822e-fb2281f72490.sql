-- Remove a política de leitura pública
DROP POLICY IF EXISTS "Allow public read access" ON public.checkout_leads;

-- Recria política restritiva que bloqueia leitura pública
CREATE POLICY "No public read access"
ON public.checkout_leads
FOR SELECT
USING (false);