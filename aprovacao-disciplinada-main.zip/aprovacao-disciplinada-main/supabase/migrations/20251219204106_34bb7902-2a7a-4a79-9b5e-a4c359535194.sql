-- Remove a política restritiva que bloqueia leitura
DROP POLICY IF EXISTS "No public read access" ON public.checkout_leads;

-- Cria política permissiva para leitura pública
CREATE POLICY "Allow public read access"
ON public.checkout_leads
FOR SELECT
USING (true);