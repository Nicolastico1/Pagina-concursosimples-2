-- Create trigger to enforce rate limiting on checkout_leads inserts
CREATE TRIGGER enforce_checkout_rate_limit
  BEFORE INSERT ON public.checkout_leads
  FOR EACH ROW
  EXECUTE FUNCTION public.check_checkout_rate_limit();